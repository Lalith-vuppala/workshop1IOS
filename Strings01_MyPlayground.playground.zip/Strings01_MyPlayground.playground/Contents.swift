import UIKit

var greeting = "Hello, playground"

var fact = "Swift is a type safe language"
 var dev = "Development of swift began in 2010"
var author = "Swift was created by chris Lattner"

print(fact.count)

fact += ", it has a better memory management"

print(fact)

dev.append(" by Apple")
 print(dev)

print(author.lowercased())

print(author.uppercased())

print(author[author.startIndex])


print(author[author.index(before: author.endIndex)])

print(fact[fact.index(before: fact.endIndex)])

print(fact[fact.index(after: fact.startIndex)])

print(author[author.index(author.endIndex,offsetBy: -6)])
print(author[author.index(author.startIndex, offsetBy: 8 )])


var medicineList = "The medicine list contains:"
var Items = "Thyronorm, galvas, calpol"
var insulin = "insugen, vitk"

if insulin.hasPrefix("insugen"){
    print("The first item in insulin is insugen")
}else{
    print("insugen is not the first item in insulin")

}

print(Items.split(separator: ","))

if insulin.contains(","){
   print("insulin contains more than one item")
    
}else{
    print("insulin contains only one item")
}

print(Items[Items.startIndex..<Items.index(Items.endIndex,offsetBy: -8)])

print(medicineList += Items[Items.index(Items.startIndex,offsetBy: 6)..<Items.endIndex])

print(insulin.remove(at: insulin.firstIndex(of: "i")!))
print(insulin.remove(at: insulin.firstIndex(of: "n")!))

print("\(medicineList), \(insulin)")

Items.insert(contentsOf: ",vitd", at:Items.endIndex)


var firtsIndexOfT = medicineList.index(after: medicineList.firstIndex(of: "T")!)
